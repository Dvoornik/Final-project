//
//  Ingredient.swift
//  Recipe-Shopping
//
//  Created by alena on 6/1/17.
//  Copyright © 2017 DeAnza. All rights reserved.
//

import UIKit

class Ingredient: NSObject {
    
}
