//
//  AddViewController.swift
//  Recipe-Shopping
//
//  Created by Steve Xuan Tu on 6/7/17.
//  Copyright © 2017 DeAnza. All rights reserved.
//

import UIKit
import CoreData

class AddViewController: UIViewController
{
    // Declared Outlets //
    @IBOutlet weak var recipeName: UITextField!
    @IBOutlet weak var recipeIngredients: UITextField!
    @IBOutlet weak var recipeDescription: UITextField!
    @IBOutlet weak var recipeImage: UITextField!
    @IBOutlet weak var recipeImagePreview: UIImageView!
    @IBOutlet weak var hiddenImageError: UILabel!
    
    // Declared Variables //
    var newRecipe : Recipe!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func clickedPreview(_ sender: Any)
    {
        if(hiddenImageError.isHidden == false)
        {
            hiddenImageError.isHidden = true
        }
        
        let name = recipeImage.text!
        
        recipeImagePreview.image = UIImage(named: name)
        if(recipeImagePreview.image == nil || recipeImagePreview.image == #imageLiteral(resourceName: "placeholder"))
        {
            recipeImagePreview.image = UIImage(named: "placeholder")
            hiddenImageError.isHidden = false
        }
    }
    
    @IBAction func clickedCancel(_ sender: Any)
    {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func clickedSave(_ sender: Any)
    {
        // Don't know what the CoreData model looks like so I'm going to leave this for now.
        
        //if let appDelegate = (UIApplication.shared.delegate as? AppDelegate)
        //{
            //newRecipe = Recipe(context: appDelegate.persistentContainer.viewContext)
            
            //newRecipe.recName = recipeName.text!
            
            //appDelegate.saveContext()
        //}
        self.dismiss(animated: true, completion: nil)
    }

    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
